Author: Brian Weinstein
Date: May 19, 2021
ese-coursera-course-1 assignment 1

"Description: 

In this programming assignment you will create a simple application that performs statistical analytics on a dataset. This assignment will help you get re-oriented with c-programming syntax and host machine compilation. We begin by setting up a version control repository on your local machine. You will then develop and test your code there. When complete, you will upload a zip of your repository to Coursera. Please read through all instructions before starting."


NOTE: 

This code was developed initially with VScode on Win10. I've compiled the code and run `stats.out` in the required VM as well. 
